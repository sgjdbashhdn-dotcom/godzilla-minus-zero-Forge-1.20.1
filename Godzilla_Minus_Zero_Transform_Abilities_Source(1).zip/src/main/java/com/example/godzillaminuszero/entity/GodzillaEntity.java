package com.example.godzillaminuszero.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;

public class GodzillaEntity extends PathfinderMob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private UUID ownerUUID;

    public GodzillaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 500.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 18.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new WaterAvoidingRandomStrollGoal(this, 0.35D));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
        // No target or damage goals: this entity is a friendly, non-damaging player avatar.
    }

    public void setOwner(UUID ownerUUID) {
        this.ownerUUID = ownerUUID;
    }

    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    public boolean isOwnedBy(Player player) {
        return ownerUUID != null && ownerUUID.equals(player.getUUID());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerUUID != null) tag.putUUID("GodzillaOwner", ownerUUID);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("GodzillaOwner")) ownerUUID = tag.getUUID("GodzillaOwner");
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().isEmpty() && passenger instanceof Player;
    }

    @Override
    public LivingEntity getControllingPassenger() {
        Entity passenger = this.getFirstPassenger();
        return passenger instanceof LivingEntity living ? living : null;
    }

    @Override
    public double getPassengersRidingOffset() {
        return this.getBbHeight() * 0.78D;
    }

    @Override
    public void travel(Vec3 travelVector) {
        if (this.isAlive() && this.getControllingPassenger() instanceof Player player) {
            this.setYRot(player.getYRot());
            this.yRotO = this.getYRot();
            this.setXRot(player.getXRot() * 0.35F);
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getYRot();

            Vec3 input = new Vec3(player.xxa, 0.0D, player.zza);
            if (input.lengthSqr() > 1.0D) input = input.normalize();
            input = input.yRot(-this.getYRot() * ((float) Math.PI / 180.0F));

            this.setSpeed((float) this.getAttributeValue(Attributes.MOVEMENT_SPEED));
            super.travel(input);
        } else {
            super.travel(travelVector);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && getControllingPassenger() instanceof Player player) {
            if (!player.hasEffect(MobEffects.INVISIBILITY)) {
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 60, 0, true, false, false));
            }
        }
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (passenger instanceof Player player && !level().isClientSide) {
            player.removeEffect(MobEffects.INVISIBILITY);
        }
    }

    // These abilities are cosmetic only: they do not damage, target, ignite, or knock back entities.
    public void useAbility(int action) {
        if (level().isClientSide || !isAlive()) return;
        switch (action) {
            case 1 -> roarEffect();
            case 2 -> dorsalFlareEffect();
            case 3 -> stompDustEffect();
            case 4 -> tailSwayEffect();
            default -> { }
        }
    }

    private void roarEffect() {
        triggerAnim("main_controller", "roar");
        level().playSound(null, blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                SoundSource.HOSTILE, 1.8F, 0.85F);
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.POOF,
                    getX(), getY() + 2.0D, getZ(), 18, 1.2D, 1.0D, 1.2D, 0.04D);
        }
    }

    private void dorsalFlareEffect() {
        triggerAnim("main_controller", "dorsal_flare");
        this.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, true, false, false));
        if (level() instanceof ServerLevel server) {
            for (int i = 0; i < 28; i++) {
                double angle = (Math.PI * 2.0D * i) / 28.0D;
                double px = getX() + Math.cos(angle) * 1.1D;
                double pz = getZ() + Math.sin(angle) * 1.1D;
                server.sendParticles(ParticleTypes.END_ROD,
                        px, getY() + 2.0D + (i % 4) * 0.35D, pz, 2, 0.05D, 0.12D, 0.05D, 0.01D);
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        px, getY() + 2.2D + (i % 3) * 0.3D, pz, 1, 0.04D, 0.08D, 0.04D, 0.0D);
            }
        }
    }

    private void stompDustEffect() {
        triggerAnim("main_controller", "stomp_emote");
        level().playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE,
                SoundSource.HOSTILE, 1.2F, 1.15F);
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.CLOUD,
                    getX(), getY() + 0.25D, getZ(), 36, 2.3D, 0.15D, 2.3D, 0.04D);
            server.sendParticles(ParticleTypes.POOF,
                    getX(), getY() + 0.3D, getZ(), 20, 1.8D, 0.2D, 1.8D, 0.03D);
        }
    }

    private void tailSwayEffect() {
        triggerAnim("main_controller", "tail_sway");
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.POOF,
                    getX(), getY() + 1.0D, getZ(), 10, 1.4D, 0.5D, 1.4D, 0.03D);
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        AnimationController<GodzillaEntity> controller = new AnimationController<>(
                this, "main_controller", 5, state -> {
                    if (state.isMoving()) {
                        state.setAndContinue(RawAnimation.begin().thenLoop("animation.godzilla_minus_zero.walk"));
                    } else {
                        state.setAndContinue(RawAnimation.begin().thenLoop("animation.godzilla_minus_zero.idle"));
                    }
                    return PlayState.CONTINUE;
                });
        controller.triggerableAnim("roar",
                RawAnimation.begin().thenPlay("animation.godzilla_minus_zero.roar"));
        controller.triggerableAnim("dorsal_flare",
                RawAnimation.begin().thenPlay("animation.godzilla_minus_zero.dorsal_flare"));
        controller.triggerableAnim("stomp_emote",
                RawAnimation.begin().thenPlay("animation.godzilla_minus_zero.stomp_emote"));
        controller.triggerableAnim("tail_sway",
                RawAnimation.begin().thenPlay("animation.godzilla_minus_zero.tail_sway"));
        controllers.add(controller);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
