package com.example.godzillaminuszero;

import com.example.godzillaminuszero.entity.GodzillaEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GodzillaMinusZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class GodzillaAttributes {
    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(GodzillaMinusZeroMod.GODZILLA.get(), GodzillaEntity.createAttributes().build());
    }
}
