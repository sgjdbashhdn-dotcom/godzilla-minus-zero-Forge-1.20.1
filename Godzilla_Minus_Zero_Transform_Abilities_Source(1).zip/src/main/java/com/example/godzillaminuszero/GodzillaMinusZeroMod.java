package com.example.godzillaminuszero;

import com.example.godzillaminuszero.entity.GodzillaEntity;
import com.example.godzillaminuszero.network.ModNetwork;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import software.bernie.geckolib.GeckoLib;

@Mod(GodzillaMinusZeroMod.MODID)
public class GodzillaMinusZeroMod {
    public static final String MODID = "godzillaminuszero";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<GodzillaEntity>> GODZILLA =
            ENTITIES.register("godzilla_minus_zero", () ->
                    EntityType.Builder.of(GodzillaEntity::new, MobCategory.CREATURE)
                            .sized(3.0F, 4.8F)
                            .clientTrackingRange(12)
                            .fireImmune()
                            .build("godzilla_minus_zero"));

    public static final RegistryObject<Item> GODZILLA_SPAWN_EGG =
            ITEMS.register("godzilla_minus_zero_spawn_egg", () ->
                    new SpawnEggItem(GODZILLA, 0x29292D, 0xB9B8A8, new Item.Properties()));

    public GodzillaMinusZeroMod() {
        GeckoLib.initialize();
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        ModNetwork.register();
    }
}
