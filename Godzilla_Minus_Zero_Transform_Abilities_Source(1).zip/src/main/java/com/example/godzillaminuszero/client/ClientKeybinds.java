package com.example.godzillaminuszero.client;

import com.example.godzillaminuszero.GodzillaMinusZeroMod;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = GodzillaMinusZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientKeybinds {
    public static final KeyMapping TRANSFORM = new KeyMapping(
            "key.godzillaminuszero.transform", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.godzillaminuszero");
    public static final KeyMapping ROAR = new KeyMapping(
            "key.godzillaminuszero.roar", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.godzillaminuszero");
    public static final KeyMapping DORSAL_FLARE = new KeyMapping(
            "key.godzillaminuszero.dorsal_flare", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.godzillaminuszero");
    public static final KeyMapping STOMP_EMOTE = new KeyMapping(
            "key.godzillaminuszero.stomp_emote", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.godzillaminuszero");
    public static final KeyMapping TAIL_SWAY = new KeyMapping(
            "key.godzillaminuszero.tail_sway", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.godzillaminuszero");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(TRANSFORM);
        event.register(ROAR);
        event.register(DORSAL_FLARE);
        event.register(STOMP_EMOTE);
        event.register(TAIL_SWAY);
    }
}
