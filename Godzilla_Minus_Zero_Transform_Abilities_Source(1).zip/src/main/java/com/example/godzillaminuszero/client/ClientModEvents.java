package com.example.godzillaminuszero.client;

import com.example.godzillaminuszero.GodzillaMinusZeroMod;
import com.example.godzillaminuszero.client.renderer.GodzillaRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GodzillaMinusZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GodzillaMinusZeroMod.GODZILLA.get(), GodzillaRenderer::new);
    }
}
