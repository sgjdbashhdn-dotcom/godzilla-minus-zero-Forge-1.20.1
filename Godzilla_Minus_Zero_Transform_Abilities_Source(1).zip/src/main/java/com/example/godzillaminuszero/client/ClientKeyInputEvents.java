package com.example.godzillaminuszero.client;

import com.example.godzillaminuszero.GodzillaMinusZeroMod;
import com.example.godzillaminuszero.network.AbilityPacket;
import com.example.godzillaminuszero.network.ModNetwork;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GodzillaMinusZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientKeyInputEvents {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        while (ClientKeybinds.TRANSFORM.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(0));
        }
        while (ClientKeybinds.ROAR.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(1));
        }
        while (ClientKeybinds.DORSAL_FLARE.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(2));
        }
        while (ClientKeybinds.STOMP_EMOTE.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(3));
        }
        while (ClientKeybinds.TAIL_SWAY.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(4));
        }
    }
}
