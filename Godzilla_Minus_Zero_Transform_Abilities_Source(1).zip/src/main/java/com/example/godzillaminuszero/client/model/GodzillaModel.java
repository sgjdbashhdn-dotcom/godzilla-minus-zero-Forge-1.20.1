package com.example.godzillaminuszero.client.model;

import com.example.godzillaminuszero.GodzillaMinusZeroMod;
import com.example.godzillaminuszero.entity.GodzillaEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class GodzillaModel extends GeoModel<GodzillaEntity> {
    @Override
    public ResourceLocation getModelResource(GodzillaEntity entity) {
        return new ResourceLocation(GodzillaMinusZeroMod.MODID, "geo/godzilla_minus_zero.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(GodzillaEntity entity) {
        return new ResourceLocation(GodzillaMinusZeroMod.MODID, "textures/entity/godzilla_minus_zero.png");
    }

    @Override
    public ResourceLocation getAnimationResource(GodzillaEntity entity) {
        return new ResourceLocation(GodzillaMinusZeroMod.MODID, "animations/godzilla_minus_zero.animation.json");
    }
}
