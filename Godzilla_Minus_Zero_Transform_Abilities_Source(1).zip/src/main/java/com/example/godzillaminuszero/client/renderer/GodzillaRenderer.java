package com.example.godzillaminuszero.client.renderer;

import com.example.godzillaminuszero.client.model.GodzillaModel;
import com.example.godzillaminuszero.entity.GodzillaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class GodzillaRenderer extends GeoEntityRenderer<GodzillaEntity> {
    public GodzillaRenderer(EntityRendererProvider.Context context) {
        super(context, new GodzillaModel());
        this.shadowRadius = 3.0F;
        this.scaleWidth = 2.5F;
        this.scaleHeight = 2.5F;
    }
}
