package com.example.godzillaminuszero.network;

import com.example.godzillaminuszero.entity.GodzillaEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class AbilityPacket {
    // 0 = transform toggle, 1 = roar, 2 = dorsal flare,
    // 3 = stomp dust emote, 4 = tail sway.
    private final int action;

    public AbilityPacket(int action) {
        this.action = action;
    }

    public static void encode(AbilityPacket msg, FriendlyByteBuf buffer) {
        buffer.writeVarInt(msg.action);
    }

    public static AbilityPacket decode(FriendlyByteBuf buffer) {
        return new AbilityPacket(buffer.readVarInt());
    }

    public static void handle(AbilityPacket msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;

            if (msg.action == 0) {
                toggleTransformation(player);
                return;
            }

            Entity vehicle = player.getVehicle();
            if (vehicle instanceof GodzillaEntity godzilla && godzilla.isOwnedBy(player)) {
                godzilla.useAbility(msg.action);
            }
        });
        context.setPacketHandled(true);
    }

    private static void toggleTransformation(ServerPlayer player) {
        Entity vehicle = player.getVehicle();
        if (vehicle instanceof GodzillaEntity godzilla && godzilla.isOwnedBy(player)) {
            player.stopRiding();
            player.removeEffect(MobEffects.INVISIBILITY);
            godzilla.discard();
            player.displayClientMessage(Component.literal("You changed back to normal."), true);
            return;
        }

        if (player.getVehicle() != null) {
            player.displayClientMessage(Component.literal("Dismount before transforming."), true);
            return;
        }

        GodzillaEntity godzilla = new GodzillaEntity(
                com.example.godzillaminuszero.GodzillaMinusZeroMod.GODZILLA.get(),
                player.serverLevel());
        godzilla.setOwner(player.getUUID());
        godzilla.moveTo(player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());

        if (player.serverLevel().addFreshEntity(godzilla)) {
            if (player.startRiding(godzilla, true)) {
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 60, 0, true, false, false));
                player.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.POOF,
                        player.getX(), player.getY() + 1.0D, player.getZ(), 32, 1.0D, 1.0D, 1.0D, 0.08D);
                player.serverLevel().playSound(null, player.blockPosition(),
                        net.minecraft.sounds.SoundEvents.ENDER_DRAGON_GROWL,
                        net.minecraft.sounds.SoundSource.HOSTILE, 1.4F, 0.85F);
                player.displayClientMessage(Component.literal(
                        "GODZILLA TRANSFORMATION! R: revert | G: roar | V: dorsal flare | B: stomp effect | H: tail sway"),
                        true);
            } else {
                godzilla.discard();
                player.displayClientMessage(Component.literal("Could not transform here. Try an open area."), true);
            }
        }
    }
}
