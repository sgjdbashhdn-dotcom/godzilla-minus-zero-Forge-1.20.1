package com.example.godzillaminuszero.network;

import com.example.godzillaminuszero.GodzillaMinusZeroMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GodzillaMinusZeroMod.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals
    );

    private ModNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(0, AbilityPacket.class,
                AbilityPacket::encode, AbilityPacket::decode, AbilityPacket::handle);
    }
}
