# Godzilla Minus Zero — Forge 1.20.1

A Forge 1.20.1 / GeckoLib 4 source project with a player-controlled Godzilla avatar.

## Player transformation and controls

Press **R** to transform into Godzilla Minus Zero. The Godzilla entity is controlled by your movement keys while your player model is hidden as its rider. Press **R** again to revert.

| Key | Ability |
|---|---|
| G | Roar (sound and particles) |
| V | Dorsal flare (temporary glowing outline and particles) |
| B | Stomp dust emote |
| H | Tail sway emote |
| R | Transform / revert |

**WASD** moves Godzilla. All listed abilities are visual/audio emotes only. They do not damage, target, ignite, or knock back entities.

The transformation is implemented as a player-controlled Godzilla mount with the player hidden as its passenger; it is not a replacement of the vanilla player renderer.

## Build

1. Install Java 17.
2. Open this folder in IntelliJ IDEA or use Gradle 8.x.
3. Run `gradle build`.
4. The compiled JAR will be created in `build/libs/`.
5. Install Minecraft Forge 1.20.1 and GeckoLib 4 for Forge in your Minecraft `mods` folder.
6. Put the compiled mod JAR in `mods`.

## Included

- Godzilla entity, geometry, texture and GeckoLib animations
- Spawn egg
- Player transformation and revert key
- WASD movement while transformed
- Non-damaging roar, dorsal flare, stomp dust and tail sway effects

## Build status

This is an updated source project. It has not been compiled or tested in a Minecraft client here because this environment does not have Gradle, Java 17, or network access to fetch the Forge/GeckoLib build dependencies. Build and test it in a Forge 1.20.1 development setup before using it in a world.
